

public class SimpleNameClass {
	public String Myid;  // Simple Time stamp to id message
	public String FirstName;
	public String LastName;
}
