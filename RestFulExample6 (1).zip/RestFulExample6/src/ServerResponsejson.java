
 

 
public class ServerResponsejson {
	public String code;  // Simple message back to the client that the call was process successfully
	public String message;
	public String errmessage;
}
